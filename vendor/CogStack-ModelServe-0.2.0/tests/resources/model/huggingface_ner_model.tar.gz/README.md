Small model used as a  token-classification to enable fast tests on that pipeline.
